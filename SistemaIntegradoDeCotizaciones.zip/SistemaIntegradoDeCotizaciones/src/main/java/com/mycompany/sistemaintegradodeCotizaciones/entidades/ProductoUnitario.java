/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaintegradodeCotizaciones.entidades;



/**
 *
 * @author Jose Lopez
 */
public class ProductoUnitario extends Producto {
    
      private double preciouni;
    public ProductoUnitario() {
        super();
    }
    
    public ProductoUnitario(int idProducto,String nombre,double preciouni,  String descripcion) {
        super(idProducto, nombre, descripcion);
        this.preciouni = preciouni;
    }
    public double getPreciouni() {
        return preciouni;
    }

    public void setPreciouni(double preciouni) {
        this.preciouni = preciouni;
    } 
    @Override
    public double calcularPrecio() {
    return this.getPreciouni();
    }
    
}
