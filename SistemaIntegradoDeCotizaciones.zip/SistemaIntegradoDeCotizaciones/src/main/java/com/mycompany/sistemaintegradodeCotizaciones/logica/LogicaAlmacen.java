/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaintegradodeCotizaciones.logica;

import com.mycompany.sistemaintegradodeCotizaciones.entidades.Almacen;
import com.mycompany.sistemaintegradodeCotizaciones.persistencia.ImpAlmacen;

/**
 *
 * @author f
 */
public class LogicaAlmacen {
    private ImpAlmacen datAlmacen;
    
    
    public boolean agregarAlmacen(Almacen a)throws IllegalArgumentException{
        return this.datAlmacen.agregarAlmacen(a);
    }
    
    public boolean eliminarAlmacen(Almacen a)throws IllegalArgumentException{
        return this.datAlmacen.eliminarAlmacen(a);
    }
    
    public Almacen buscarAlmacen(int a)throws IllegalArgumentException{
        return this.datAlmacen.buscarAlmacen(a);
    }
    
    public Almacen obtenerAlmacen(Almacen a)throws IllegalArgumentException{
        return this.datAlmacen.obtenerAlmacen(a);
    }
}
