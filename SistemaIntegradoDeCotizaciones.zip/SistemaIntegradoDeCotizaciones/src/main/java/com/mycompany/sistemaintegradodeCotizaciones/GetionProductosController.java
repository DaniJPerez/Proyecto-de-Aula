/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.mycompany.sistemaintegradodeCotizaciones;

import com.mycompany.sistemaintegradodeCotizaciones.entidades.Producto;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * FXML Controller class
 *
 * @author f
 */
public class GetionProductosController implements Initializable {
    @FXML
    private Label precioProducto, labelNombreProducto, labelDescriccionProducto;
    @FXML
    private Button agregarProducto;
    @FXML
    private ListView<Producto> listProductos;
    @FXML
    private TableView<Producto> tablaProductos;
    @FXML
    private TableColumn tablaId;
    @FXML
    private TableColumn tablaNombre;
    @FXML
    private TableColumn tablaPrecio;
    @FXML
    private TableColumn tablaDesccicion;
    
    private ObservableList<Producto> produc;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        System.out.println("Inicio ");
        this.tablaNombre.setCellValueFactory(new PropertyValueFactory("nombre"));
        this.tablaId.setCellValueFactory(new PropertyValueFactory("id"));
        this.tablaPrecio.setCellValueFactory(new PropertyValueFactory("precio"));
        this.tablaDesccicion.setCellValueFactory(new PropertyValueFactory("descriccion"));
        this.produc = FXCollections.observableArrayList();
        //this.castListProducts(this.productModel.getListProduct()); ess necesario que se añada una clase logica expecifica con una interfaz
        this.tablaProductos.setItems(produc);
        /*
        for(Product p: this.productModel.getListProduct()){
            System.out.println(p);
        }
        de igual forma aqui
        */
        
      /*  public void castListProducts(List<Product>list) {
        for (Product p : list) {
            ProductDto dto = new ProductDto(p);
            this.data.add(dto);
        }
        Usar una clase para añadir a los productos valores por defecto, como lo hace el profesor en el proyecto de productos
     */
     /* public void keyTypedTxTNombre(KeyEven e){
          for (Product p : list) {
            ProductDto dto = new ProductDto(p);
            this.data.add(dto);
      } igualmente.
        }
    */
    }    
    
    
}
