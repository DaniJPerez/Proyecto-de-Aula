/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaintegradodeCotizaciones.dto;

import com.mycompany.sistemaintegradodeCotizaciones.entidades.Almacen;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

/**
 *
 * @author f
 */
public class AlmacenDto {
    private SimpleIntegerProperty idAlmacen;
    private SimpleStringProperty nombre;
    private SimpleStringProperty ubicacion;

    public AlmacenDto(Almacen odj) {
        this.idAlmacen = new SimpleIntegerProperty(odj.getIdAlmacen());
        this.nombre = new SimpleStringProperty(odj.getNombre());
        this.ubicacion = new SimpleStringProperty(odj.getUbicacion());
    }

    public int getIdAlmacen() {
        return idAlmacen.get();
    }

    public void setIdAlmacen(int idAlmacen) {
        this.idAlmacen.set(idAlmacen);
    }

    public String getNombre() {
        return nombre.get();
    }

    public void setNombre(String nombre) {
        this.nombre.set(nombre);
    }

    public String getUbicacion() {
        return ubicacion.get();
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion.set(ubicacion);
    }
    

    
    
    
}
