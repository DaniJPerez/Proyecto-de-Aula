/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaintegradodeCotizaciones.persistencia;

import com.mycompany.sistemaintegradodeCotizaciones.entidades.Producto;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author f
 */
public class InventarioImpleMaps implements ImpInventario{
          private Map<Integer, Producto> registroProducto;
       
    public InventarioImpleMaps() {
        this.registroProducto = new HashMap();
    }

    public Map<Integer, Producto> getRegistroProducto() {
        return registroProducto;
    }

    public void setRegistroProducto(Map<Integer, Producto> registroProducto) {
        this.registroProducto = registroProducto;
    }

    @Override
    public String toString() {
        return "InventarioImpleMaps{" + "producto=" + registroProducto + '}';
    }

     public boolean agregarProducto(Producto a) {
        this.registroProducto.put(a.getIdProducto(), a);
        return true;
    }

    public Producto buscarProducto(int id) {
        for(Map.Entry<Integer,Producto>producto:this.registroProducto.entrySet()){
            if(producto.getKey()==id){
                return (Producto)producto;
            }
       }
       return null;
    }

    public boolean eliminarProducto(Producto a) {
         return this.registroProducto.remove(a.getIdProducto(), a);
    }

    public ArrayList<Producto> obtenerProducto(int a) {
        return  new ArrayList(this.registroProducto.values());
        
    } 
    
}
