/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaintegradodeCotizaciones.persistencia;

import com.mycompany.sistemaintegradodeCotizaciones.entidades.Cliente;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Jose Lopez
 */
public class GestionClientesImpleMaps implements ImpClientes{
    private Map<Integer, Cliente> registroCliente;
       
    public GestionClientesImpleMaps() {
        this.registroCliente = new HashMap();
    }

    @Override
    public String toString() {
        return "GestionClientesImpleMaps{" + "cliente=" + registroCliente + '}';
    }

    public Map<Integer, Cliente> getRegistroCliente() {
        return registroCliente;
    }

    public void setRegistroCliente(Map<Integer, Cliente> registroCliente) {
        this.registroCliente = registroCliente;
    }

     public boolean agregarCliente(Cliente a) {
        this.registroCliente.put(a.getIdCliente(), a);
        return true;
    }

    public Cliente buscarCliente(int id) {
        for(Map.Entry<Integer,Cliente>cliente:this.registroCliente.entrySet()){
            if(cliente.getKey()==id){
                return (Cliente)cliente;
            }
       }
       return null;
    }

    public boolean eliminarCliente(Cliente a) {
         return this.registroCliente.remove(a.getIdCliente(), a);
    }

   
    public Cliente obtenerCliente(Cliente a) {
       for(Map.Entry<Integer,Cliente>cliente:this.registroCliente.entrySet()){
            if(cliente.equals(a)){
                return (Cliente) cliente;
            }
       }
       return null;
        
    }
    
    public boolean examinarExistencia(int idCliente){
        return this.registroCliente.containsKey(idCliente);
    }
}
