/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaintegradodeCotizaciones.persistencia;

import com.mycompany.sistemaintegradodeCotizaciones.entidades.Almacen;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Jose Lopez
 */
public class GestionAlmacenImpleMaps implements ImpAlmacen{
    private Map<Integer, Almacen> registroAlmacen;
    
    public GestionAlmacenImpleMaps() {
        this.registroAlmacen = new HashMap();
    }
    
    public Map<Integer, Almacen> getRegistroAlmacen() {
        return registroAlmacen;
    }

    public void setRegistroAlmacen(Map<Integer, Almacen> registroAlmacen) {
        this.registroAlmacen = registroAlmacen;
    }
    
     public boolean agregarAlmacen(Almacen a) {
        this.registroAlmacen.put(a.getIdAlmacen(), a);
        return true;
    }

    public Almacen buscarAlmacen(int id) {
        for(Map.Entry<Integer,Almacen>almacen:this.registroAlmacen.entrySet()){
            if(almacen.getKey()==id){
                return (Almacen)almacen;
            }
       }
       return null;
    }
    
    public boolean eliminarAlmacen(Almacen a) {
         return this.registroAlmacen.remove(a.getIdAlmacen(), a);
    }
    @Override
    public Almacen obtenerAlmacen(Almacen a) {
       for(Map.Entry<Integer,Almacen>almacen:this.registroAlmacen.entrySet()){
            if(almacen.equals(a)){
                return (Almacen)almacen;
            }
       }
       return null;
        
    }

    @Override
    public String toString() {
        return "GestionAlmacenImpleMaps{" + "registroAlmacen=" + registroAlmacen + '}';
    }

}
