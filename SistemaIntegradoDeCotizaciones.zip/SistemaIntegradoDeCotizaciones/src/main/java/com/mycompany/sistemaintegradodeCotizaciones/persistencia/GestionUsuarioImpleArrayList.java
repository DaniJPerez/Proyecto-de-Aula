/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaintegradodeCotizaciones.persistencia;

import com.mycompany.sistemaintegradodeCotizaciones.entidades.Usuario;
import java.util.ArrayList;

/**
 *
 * @author f
 */
public class GestionUsuarioImpleArrayList implements ImpUsuario{
    private ArrayList<Usuario> registroUsurio;

    public GestionUsuarioImpleArrayList() {
        this.registroUsurio=new ArrayList();
    }

    public ArrayList<Usuario> getRegistroUsurio() {
        return registroUsurio;
    }

    public void setRegistroUsurio(ArrayList<Usuario> registroUsurio) {
        this.registroUsurio = registroUsurio;
    }
    
    public boolean agregarUsuario(Usuario a){
        return this.registroUsurio.add(a);
    }
    
    public boolean eliminarUsuario(Usuario a){
        return this.registroUsurio.add(a);
    }
    
    public Usuario buscarUsuario(int a){
        for(Usuario e: this.registroUsurio){
            if(e.getIdUsuario()==a){
                return e;
            }
        }
        return null;
    }
    
    public Usuario obtenerUsuario(Usuario a){
        for(Usuario e: this.registroUsurio){
            if(a.equals(e)){
                return e;
            }
        }
        return null;
    }
    
}
