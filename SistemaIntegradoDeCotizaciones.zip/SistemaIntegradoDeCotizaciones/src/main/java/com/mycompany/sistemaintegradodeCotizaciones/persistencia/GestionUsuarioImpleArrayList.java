/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaintegradodeCotizaciones.persistencia;

import com.mycompany.sistemaintegradodeCotizaciones.entidades.Usuario;
import java.util.ArrayList;

/**
 *
 * @author f
 */
public class GestionUsuarioImpleArrayList implements ImpUsuario{
    private ArrayList<Usuario> registroUsurio;

    public GestionUsuarioImpleArrayList() {
        this.registroUsurio=new ArrayList();
    }

    public ArrayList<Usuario> getRegistroUsurio() {
        return registroUsurio;
    }

    public void setRegistroUsurio(ArrayList<Usuario> registroUsurio) {
        this.registroUsurio = registroUsurio;
    }
    
    @Override
    public boolean agregarUsuario(Usuario a)throws IllegalStateException,IllegalArgumentException {
        if(a==null)
            throw new IllegalArgumentException("No se puede registrar un Usuario NULL");
        
        if(a.getNombre().isBlank())
            throw new IllegalArgumentException("El primer nombre del usuario no puede ser NULL");
        
        if(a.getPassword().isBlank())
            throw new IllegalArgumentException("El PASSWORD no puede ser NULL");
        
        for(Usuario u:this.registroUsurio){
            if(u.getNombre().equals(a.getNombre())){
                throw new IllegalStateException("El usuario "+a.getNombre()+ " No esta disponible");
            }
        }
        
        return this.registroUsurio.add(a);
    }
    
    @Override
    public boolean eliminarUsuario(Usuario a)throws IllegalArgumentException{
        if(a==null)
            throw new IllegalArgumentException("No es posible eliminar un Usuario NULO");
        return this.registroUsurio.add(a);
    }
    
    @Override
    public Usuario buscarUsuario(int a)throws IllegalArgumentException{
        Usuario usuario=null;
        for(Usuario e: this.registroUsurio){
            if(e.getIdUsuario()==a){
                usuario= e;
            }
        }
        if(usuario==null)
            throw new IllegalArgumentException("No hay usuario regisrado con ese id ");
        return usuario;
    }
    
    @Override
    public Usuario obtenerUsuario(Usuario a)throws IllegalArgumentException{
        Usuario usuario=null;
        for(Usuario e: this.registroUsurio){
            if(a.equals(e)){
                usuario= e;
            }
        }
        if(usuario==null)
            throw new IllegalArgumentException("No existe ese usuario ");
        return usuario;
    }
    
}
