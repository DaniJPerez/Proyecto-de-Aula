/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaintegradodeCotizaciones.logica;

import com.mycompany.sistemaintegradodeCotizaciones.entidades.Almacen;
import com.mycompany.sistemaintegradodeCotizaciones.entidades.Cliente;
import com.mycompany.sistemaintegradodeCotizaciones.entidades.Cotizacion;
import com.mycompany.sistemaintegradodeCotizaciones.entidades.Producto;
import com.mycompany.sistemaintegradodeCotizaciones.entidades.Usuario;
import com.mycompany.sistemaintegradodeCotizaciones.persistencia.GestionAlmacenImpleArrayList;
import com.mycompany.sistemaintegradodeCotizaciones.persistencia.GestionAlmacenImpleMaps;
import com.mycompany.sistemaintegradodeCotizaciones.persistencia.GestionClientesImpleArrayList;
import com.mycompany.sistemaintegradodeCotizaciones.persistencia.GestionClientesImpleMaps;
import com.mycompany.sistemaintegradodeCotizaciones.persistencia.GestionCotizacionImpleArrayList;
import com.mycompany.sistemaintegradodeCotizaciones.persistencia.GestionCotizacionImpleMaps;
import com.mycompany.sistemaintegradodeCotizaciones.persistencia.GestionUsuarioImpMaps;
import com.mycompany.sistemaintegradodeCotizaciones.persistencia.GestionUsuarioImpleArrayList;
import com.mycompany.sistemaintegradodeCotizaciones.persistencia.InventarioImpleArrayList;
import com.mycompany.sistemaintegradodeCotizaciones.persistencia.InventarioImpleMaps;
import java.util.ArrayList;

/**
 *
 * @author f
 */
public class Logica {
    
    private InventarioImpleMaps persistenciaInventarioMaps;
    private InventarioImpleArrayList persistenciaInventarioArrayList;
    private GestionCotizacionImpleMaps persistenciaCotizacionMaps;
    private GestionCotizacionImpleArrayList persistenciaCotizacionArrayList;
    private GestionAlmacenImpleMaps persistenciaAlmacenMaps;
    private GestionAlmacenImpleArrayList persistenciaAlmacenArrayList;
    private GestionClientesImpleMaps persistenciaClienteMaps;
    private GestionClientesImpleArrayList persitenciaClienteArrayList;
    private GestionUsuarioImpMaps persistenciaUsuarioMaps;
    private GestionUsuarioImpleArrayList persistenciaUsuarioArrayList;
    

    public Logica() {
        this.persistenciaInventarioMaps = new InventarioImpleMaps();
        this.persistenciaInventarioArrayList = new InventarioImpleArrayList();
        this.persistenciaCotizacionMaps = new GestionCotizacionImpleMaps();
        this.persistenciaCotizacionArrayList = new GestionCotizacionImpleArrayList();
        this.persistenciaAlmacenMaps = new GestionAlmacenImpleMaps();
        this.persistenciaAlmacenArrayList = new GestionAlmacenImpleArrayList();
        this.persistenciaClienteMaps = new GestionClientesImpleMaps();
        this.persitenciaClienteArrayList = new GestionClientesImpleArrayList();
        this.persistenciaUsuarioMaps = new GestionUsuarioImpMaps();
        this.persistenciaUsuarioArrayList = new GestionUsuarioImpleArrayList();
        this.persistenciaInventarioArrayList = new InventarioImpleArrayList();
    }

    public InventarioImpleMaps getPersistenciaInventarioMaps() {
        return persistenciaInventarioMaps;
    }

    public void setPersistenciaInventarioMaps(InventarioImpleMaps persistenciaInventarioMaps) {
        this.persistenciaInventarioMaps = persistenciaInventarioMaps;
    }

    public InventarioImpleArrayList getPersistenciaInventarioArrayList() {
        return persistenciaInventarioArrayList;
    }

    public void setPersistenciaInventarioArrayList(InventarioImpleArrayList persistenciaInventarioArrayList) {
        this.persistenciaInventarioArrayList = persistenciaInventarioArrayList;
    }

    public GestionCotizacionImpleMaps getPersistenciaCotizacionMaps() {
        return persistenciaCotizacionMaps;
    }

    public void setPersistenciaCotizacionMaps(GestionCotizacionImpleMaps persistenciaCotizacionMaps) {
        this.persistenciaCotizacionMaps = persistenciaCotizacionMaps;
    }

    public GestionCotizacionImpleArrayList getPersistenciaCotizacionArrayList() {
        return persistenciaCotizacionArrayList;
    }

    public void setPersistenciaCotizacionArrayList(GestionCotizacionImpleArrayList persistenciaCotizacionArrayList) {
        this.persistenciaCotizacionArrayList = persistenciaCotizacionArrayList;
    }

    public GestionAlmacenImpleMaps getPersistenciaAlmacenMaps() {
        return persistenciaAlmacenMaps;
    }

    public void setPersistenciaAlmacenMaps(GestionAlmacenImpleMaps persistenciaAlmacenMaps) {
        this.persistenciaAlmacenMaps = persistenciaAlmacenMaps;
    }

    public GestionAlmacenImpleArrayList getPersistenciaAlmacenArrayList() {
        return persistenciaAlmacenArrayList;
    }

    public void setPersistenciaAlmacenArrayList(GestionAlmacenImpleArrayList persistenciaAlmacenArrayList) {
        this.persistenciaAlmacenArrayList = persistenciaAlmacenArrayList;
    }

    public GestionClientesImpleMaps getPersistenciaClienteMaps() {
        return persistenciaClienteMaps;
    }

    public void setPersistenciaClienteMaps(GestionClientesImpleMaps persistenciaClienteMaps) {
        this.persistenciaClienteMaps = persistenciaClienteMaps;
    }

    public GestionClientesImpleArrayList getPersitenciaClienteArrayList() {
        return persitenciaClienteArrayList;
    }

    public void setPersitenciaClienteArrayList(GestionClientesImpleArrayList persitenciaClienteArrayList) {
        this.persitenciaClienteArrayList = persitenciaClienteArrayList;
    }

    public GestionUsuarioImpMaps getPersistenciaUsuarioMaps() {
        return persistenciaUsuarioMaps;
    }

    public void setPersistenciaUsuarioMaps(GestionUsuarioImpMaps persistenciaUsuarioMaps) {
        this.persistenciaUsuarioMaps = persistenciaUsuarioMaps;
    }

    public GestionUsuarioImpleArrayList getPersistenciaUsuarioArrayList() {
        return persistenciaUsuarioArrayList;
    }

    public void setPersistenciaUsuarioArrayList(GestionUsuarioImpleArrayList persistenciaUsuarioArrayList) {
        this.persistenciaUsuarioArrayList = persistenciaUsuarioArrayList;
    }

    public InventarioImpleArrayList getPersistenciaInventarioArryList() {
        return persistenciaInventarioArrayList;
    }

    public void setPersistenciaInventarioArryList(InventarioImpleMaps persistenciaInventarioArryList) {
        this.persistenciaInventarioArrayList = persistenciaInventarioArrayList;
    }

    @Override
    public String toString() {
        return "Logica{" + "persistenciaInventarioMaps=" + persistenciaInventarioMaps + ", persistenciaInventarioArrayList=" + persistenciaInventarioArrayList + ", persistenciaCotizacionMaps=" + persistenciaCotizacionMaps + ", persistenciaCotizacionArrayList=" + persistenciaCotizacionArrayList + ", persistenciaAlmacenMaps=" + persistenciaAlmacenMaps + ", persistenciaAlmacenArrayList=" + persistenciaAlmacenArrayList + ", persistenciaClienteMaps=" + persistenciaClienteMaps + ", persitenciaClienteArrayList=" + persitenciaClienteArrayList + ", persistenciaUsuarioMaps=" + persistenciaUsuarioMaps + ", persistenciaUsuarioArrayList=" + persistenciaUsuarioArrayList  +  '}';
    }
    
     public boolean agregarAlmacenArrayList(Almacen a){
        return this.persistenciaAlmacenArrayList.agregarAlmacen(a);
    }
    
    public boolean eliminarAlmacenArrayList(Almacen a){
        return this.persistenciaAlmacenArrayList.agregarAlmacen(a);
    }
    
    public Almacen buscarAlmacenArrayList(int a){
        return this.persistenciaAlmacenArrayList.buscarAlmacen(a);
    }
    
    public Almacen obtenerAlmacenArrayList(Almacen a){
         return this.persistenciaAlmacenArrayList.obtenerAlmacen(a);
    }
    
     public boolean agregarAlmacenMaps(Almacen a) {
        return this.persistenciaAlmacenMaps.agregarAlmacen(a);
    }

    public Almacen buscarAlmacenMaps(int id) {
       return this.persistenciaAlmacenMaps.buscarAlmacen(id);
    }
    

    public boolean eliminarAlmacenMaps(Almacen a) {
         return this.persistenciaAlmacenMaps.eliminarAlmacen(a);
    }
   
    public ArrayList<Almacen> obtenerAlmacenMaps(int codigo) {
        return  this.persistenciaAlmacenMaps.obtener(codigo);
        
    }
    
     public boolean agregarClienteArrayList(Cliente a){
        return this.persitenciaClienteArrayList.agregarCliente(a);
    }
    
    public boolean eliminarClienteArrayList(Cliente a){
        return this.persitenciaClienteArrayList.eliminarCliente(a);
    }
    
    public Cliente buscarClienteArraylist(int a){
        return this.persitenciaClienteArrayList.buscarCliente(a);
    }
    
    public Cliente obtenerClienteArrayList(Cliente a){
        return this.persitenciaClienteArrayList.obtenerCliente(a);
    }
    
     public boolean agregarClienteMaps(Cliente a) {
        return this.persistenciaClienteMaps.agregarCliente(a);
    }

    public Cliente buscarClienteMaps(int id) {
        return this.persistenciaClienteMaps.buscarCliente(id);
    }

    public boolean eliminarClienteMaps(Cliente a) {
         return this.persistenciaClienteMaps.eliminarCliente(a);
    }

   
    public ArrayList<Cliente> obtenerClienteMaps(int id) {
        return this.persistenciaClienteMaps.obtenerCliente(id);
        
    }
    
    public boolean examinarExistenciaMaps(int idCliente){
        return this.persistenciaClienteMaps.examinarExistencia(idCliente);
    }
    
    public boolean agregarCotizacionArrayList(Cotizacion a){
        return this.persistenciaCotizacionArrayList.agregarCotizacion(a);
    }
    
    public boolean eliminarCotizacionArrayList(Cotizacion a){
        return this.persistenciaCotizacionArrayList.eliminarCotizacion(a);
    }
    
    public Cotizacion buscarCotizacionArrayList(int a){
        return this.persistenciaCotizacionArrayList.buscarCotizacion(a);
    }
    
    public Cotizacion obtenerCotizacionArrayList(Cotizacion a){
        return this.persistenciaCotizacionArrayList.obtenerCotizacion(a);
    }
    
     public boolean agregarCotizacionMaps(Cotizacion a) {
        return this.persistenciaCotizacionMaps.agregarCotizacion(a);
    }

    public Cotizacion buscarCotizacionMaps(int id) {
        return this.persistenciaCotizacionMaps.buscarCotizacion(id);
    }

    public boolean eliminarCotizacionMaps(Cotizacion a) {
         return this.persistenciaCotizacionMaps.eliminarCotizacion(a);
    }

   
    public ArrayList<Cotizacion> obtenerCotizacionMaps(Cotizacion a) {
        return this.persistenciaCotizacionMaps.obtenerCotizacion(a);
        
    }
    
     public boolean agregarUsuarioMaps(Usuario a) {
        return this.persistenciaUsuarioMaps.agregarUsuario(a);
    }

    public Usuario buscarUsuarioMaps(int id) {
        return this.persistenciaUsuarioMaps.buscarUsuario(id);
    }

    public boolean eliminarUsuarioMaps(Usuario a) {
         return this.persistenciaUsuarioMaps.eliminarUsuario(a);
    }

   
    public ArrayList<Usuario> obtenerUsuarioMaps(int id) {
        return this.persistenciaUsuarioMaps.obtenerUsuario(id);
        
    }
    
     public boolean agregarUsuarioArrayList(Usuario a){
        return this.persistenciaUsuarioArrayList.agregarUsuario(a);
    }
    
    public boolean eliminarUsuarioArrayList(Usuario a){
        return this.persistenciaUsuarioArrayList.eliminarUsuario(a);
    }
    
    public Usuario buscarUsuarioArrayList(int a){
        return this.persistenciaUsuarioArrayList.buscarUsuario(a);
    }
    
    public Usuario obtenerUsuarioArrayList(Usuario a){
        return this.persistenciaUsuarioArrayList.obtenerUsuario(a);
    }
    
    public boolean agregarProductoArrayList(Producto a){
        return this.persistenciaInventarioArrayList.agregarProducto(a);
    }
    
    public boolean eliminarProductoArrayList(Producto a){
        return this.persistenciaInventarioArrayList.eliminarProducto(a);
    }
    
    public Producto buscarProductoArrayList(int a){
        return this.persistenciaInventarioArrayList.buscarProducto(a);
    }
    
    public Producto obtenerProductoArrayList(Producto a){
        return this.persistenciaInventarioArrayList.obtenerProducto(a);
    }
    
     public boolean agregarProductoMaps(Producto a) {
        return this.persistenciaInventarioMaps.agregarProducto(a);
    }

    public Producto buscarProductoMaps(int id) {
        return this.persistenciaInventarioMaps.buscarProducto(id);
    }

    public boolean eliminarProductoMaps(Producto a) {
         return this.persistenciaInventarioMaps.eliminarProducto(a);
    }

    public ArrayList<Producto> obtenerProductoMaps(int a) {
        return  this.persistenciaInventarioMaps.obtenerProducto(a);
        
    } 
    
    
}
