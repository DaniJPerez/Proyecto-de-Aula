/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.sistemaintegradodeCotizaciones.persistencia;

import com.mycompany.sistemaintegradodeCotizaciones.entidades.Usuario;
import java.util.ArrayList;

/**
 *
 * @author f
 */
public interface ImpUsuario {
    public boolean agregarUsuario(Usuario a);
    public Usuario buscarUsuario(int id);
    public boolean eliminarUsuario(Usuario a);
    public Usuario obtenerUsuario(Usuario a);
    
}
