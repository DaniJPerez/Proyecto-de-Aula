/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaintegradodeCotizaciones.persistencia;

import com.mycompany.sistemaintegradodeCotizaciones.entidades.Cliente;
import java.util.ArrayList;

/**
 *
 * @author f
 */
public class GestionClientesImpleArrayList implements ImpClientes{
    private ArrayList<Cliente> Registrocliente;

    public GestionClientesImpleArrayList() {
       this.Registrocliente= new ArrayList(); 
    }

    public ArrayList<Cliente> getRegistrocliente() {
        return Registrocliente;
    }

    public void setRegistrocliente(ArrayList<Cliente> Registrocliente) {
        this.Registrocliente = Registrocliente;
    }

    @Override
    public String toString() {
        return "GestionClientesImpleArrayList{" + "cliente=" + Registrocliente + '}';
    }
    
    public boolean agregarCliente(Cliente a){
        return this.Registrocliente.add(a);
    }
    
    public boolean eliminarCliente(Cliente a){
        return this.Registrocliente.remove(a);
    }
    
    public Cliente buscarCliente(int a){
        for(Cliente e : this.Registrocliente){
            if(e.getIdCliente()==a){
                return e;
            }
        }
        return null;
    }
    
    public Cliente obtenerCliente(Cliente a){
        for(Cliente e : this.Registrocliente){
            if(a.equals(e)){
                return e;
            }
        }
        return null;
    }
}
