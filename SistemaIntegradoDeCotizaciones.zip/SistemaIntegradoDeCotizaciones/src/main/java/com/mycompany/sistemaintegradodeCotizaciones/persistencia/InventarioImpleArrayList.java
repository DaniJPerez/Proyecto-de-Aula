/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaintegradodeCotizaciones.persistencia;

import com.mycompany.sistemaintegradodeCotizaciones.entidades.Cotizacion;
import com.mycompany.sistemaintegradodeCotizaciones.entidades.Producto;
import java.util.ArrayList;

/**
 *
 * @author f
 */
public class InventarioImpleArrayList implements ImpInventario{
    private ArrayList<Producto> registroProducto;

    public InventarioImpleArrayList() {
        this.registroProducto = new ArrayList();
    }

    public InventarioImpleArrayList(ArrayList<Cotizacion> registroCotizacion) {
        this.registroProducto = new ArrayList();
    }

    public ArrayList<Producto> getRegistroCotizacion() {
        return registroProducto;
    }

    public void setRegistroCotizacion(ArrayList<Producto> registroProducto) {
        this.registroProducto = registroProducto;
    }

    @Override
    public String toString() {
        return "InventarioImpleArrayList{" + "registroProducto=" + registroProducto + '}';
    }
    
    @Override
    public boolean agregarProducto(Producto a)throws IllegalArgumentException{
        if(a==null)
            throw new IllegalArgumentException("No es Posible registrar un Producto con valor Nulo ");
        if(a.getDescripcion().isBlank())
            throw new IllegalArgumentException("El producto no tiene registrada la descripcion ");
        if(a.getPrecio()<0)
            throw new IllegalArgumentException("El producto no puede tener un valor menor a cero ");
        if(a.getNombre().length()==0)
            throw new IllegalArgumentException("El producto debe tener un nombre inscrito ");
        return registroProducto.add(a);
    }
    
    @Override
    public boolean eliminarProducto(Producto a)throws IllegalArgumentException{
        if(a==null)
            throw new IllegalArgumentException("No hay prodcto que eliminar ");
        
        return registroProducto.remove(a);   
    }
    
    @Override
    public Producto buscarProducto(int a)throws IllegalArgumentException{
        Producto producto=null;
        for(Producto e : this.registroProducto){
            if(e.getIdProducto()==a){
                producto=e;
            }
        }
        if(producto==null)
            throw new IllegalArgumentException("No hay producto regisrado con ese nombre ");
        return producto;
        
    }
    
    @Override
    public Producto obtenerProducto(Producto a)throws IllegalArgumentException{
        Producto producto=null;
        for(Producto e : this.registroProducto){
            if(a.equals(e)){
                producto= e;
            }
        }
        if(producto==null)
            throw new IllegalArgumentException("No existe ese producto ");
        return producto;
    }   
    
    
    
    
}
