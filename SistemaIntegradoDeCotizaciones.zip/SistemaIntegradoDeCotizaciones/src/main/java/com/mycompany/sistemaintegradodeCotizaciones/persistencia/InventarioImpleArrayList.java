/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaintegradodeCotizaciones.persistencia;

import com.mycompany.sistemaintegradodeCotizaciones.entidades.Cotizacion;
import com.mycompany.sistemaintegradodeCotizaciones.entidades.Producto;
import java.util.ArrayList;

/**
 *
 * @author f
 */
public class InventarioImpleArrayList implements ImpInventario{
    private ArrayList<Producto> registroProducto;

    public InventarioImpleArrayList() {
        this.registroProducto = new ArrayList();
    }

    public InventarioImpleArrayList(ArrayList<Cotizacion> registroCotizacion) {
        this.registroProducto = new ArrayList();
    }

    public ArrayList<Producto> getRegistroCotizacion() {
        return registroProducto;
    }

    public void setRegistroCotizacion(ArrayList<Producto> registroProducto) {
        this.registroProducto = registroProducto;
    }

    @Override
    public String toString() {
        return "InventarioImpleArrayList{" + "registroProducto=" + registroProducto + '}';
    }
    
    public boolean agregarProducto(Producto a){
        return registroProducto.add(a);
    }
    
    public boolean eliminarProducto(Producto a){
        return registroProducto.remove(a);
    }
    
    public Producto buscarProducto(int a){
        for(Producto e : this.registroProducto){
            if(e.getIdProducto()==a){
                return e;
            }
        }
        return null;
    }
    
    public Producto obtenerProducto(Producto a){
        for(Producto e : this.registroProducto){
            if(a.equals(e)){
                return e;
            }
        }
        return null;
    }
    
    
    
    
}
