/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaintegradodeCotizaciones.logica;

import com.mycompany.sistemaintegradodeCotizaciones.entidades.Empleado;
import com.mycompany.sistemaintegradodeCotizaciones.entidades.Gerente;
import com.mycompany.sistemaintegradodeCotizaciones.entidades.Usuario;
import com.mycompany.sistemaintegradodeCotizaciones.persistencia.GestionUsuarioImpleArrayList;
import com.mycompany.sistemaintegradodeCotizaciones.persistencia.ImpUsuario;

/**
 *
 * @author f
 */
public class LogicaUsuario{
    private ImpUsuario datUsuario;
    private final String nombre= "Daniel";
    private final String password="12345";
    
    public void ListaUsuarios(){
        this.datUsuario= new GestionUsuarioImpleArrayList();
        Usuario a= new Gerente("Gerente Local",10,"Daniel","12345",true);
        Usuario b= new Empleado("cajera",12,"Sara","12345",false);
        Usuario c= new Empleado("vendedor",14,"Fernando","12345",false);
    }
    public LogicaUsuario() {
    
    }
    
   /* public boolean Login(String name, String password){
        return (name.equals(nombre)&&password.equals(password));
    } */
    
    public boolean agregarUsuario(Usuario a)throws IllegalStateException,IllegalArgumentException{
        return this.datUsuario.agregarUsuario(a);
    }
    
    public Usuario buscarUsuario(int id)throws IllegalStateException,IllegalArgumentException{
        return this.datUsuario.buscarUsuario(id);
    }
    
    public boolean eliminarUsuario(Usuario a)throws IllegalStateException,IllegalArgumentException{
        return this.datUsuario.eliminarUsuario(a);
    }
   
    public Usuario obtenerUsuario(Usuario a)throws IllegalStateException,IllegalArgumentException{
        return this.datUsuario.obtenerUsuario(a);
    }
    
}
