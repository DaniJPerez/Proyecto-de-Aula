/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaintegradodeCotizaciones.entidades;
import com.mycompany.sistemaintegradodeCotizaciones.logica.LogicaInventario;
import com.mycompany.sistemaintegradodeCotizaciones.persistencia.InventarioImpleMaps;
import java.util.ArrayList;



public abstract class Producto {
    private double precio;
    private LogicaInventario logica= new LogicaInventario();
    private int idProducto;
    private String nombre;
    private String descripcion;
    
    
    public Producto() {
    }

    public Producto(int idProducto, String nombre,double precio, String descripcion) {
        this.precio= precio;
        this.idProducto = idProducto;
        this.nombre = nombre;
        this.descripcion = descripcion;
        
    }
    
    public void setProducto(Producto producto){
        this.idProducto = producto.getIdProducto();
        this.nombre = producto.nombre;
        this.descripcion = producto.descripcion;
    }
    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    
    
    @Override
    public String toString() {
        return "Producto{" + "idProducto=" + idProducto + ", nombre=" + nombre + ", descripcion=" + descripcion +  '}';
    }
    
    public boolean registrar(){
        return false;
    }
    
   public Producto buscarInventario(Producto e){
        return logica.obtenerProducto(e);
    }
   
   public double calcularPrecio(int a){
       return this.precio*a;
   }
}
