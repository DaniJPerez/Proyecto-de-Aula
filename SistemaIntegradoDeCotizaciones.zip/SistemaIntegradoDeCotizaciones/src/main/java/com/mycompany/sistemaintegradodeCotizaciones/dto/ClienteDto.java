/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaintegradodeCotizaciones.dto;

import com.mycompany.sistemaintegradodeCotizaciones.entidades.Cliente;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

/**
 *
 * @author f
 */
public class ClienteDto {
    private SimpleIntegerProperty idCliente;
    private SimpleStringProperty nombre;
    private SimpleStringProperty direnccion;
    private SimpleDoubleProperty telefono;

    public ClienteDto(Cliente odj) {
        this.idCliente = new SimpleIntegerProperty(odj.getIdCliente());
        this.nombre= new SimpleStringProperty(odj.getNombre());
        this.direnccion = new SimpleStringProperty(odj.getDirenccion());
        this.telefono = new SimpleDoubleProperty(odj.getTelefono());
    }

    public int getIdCliente() {
        return idCliente.get();
    }

    public void setIdCliente(int idCliente) {
        this.idCliente.set(idCliente);
    }

    public String getNombre() {
        return nombre.get();
    }

    public void setNombre(String nombre) {
        this.nombre.set(nombre);
    }

    public String getDirenccion() {
        return direnccion.get();
    }

    public void setDirenccion(String direnccion) {
        this.direnccion.set(direnccion);
    }

    public double getTelefono() {
        return telefono.get();
    }

    public void setTelefono(double telefono) {
        this.telefono.set(telefono);
    }
   
    
}
