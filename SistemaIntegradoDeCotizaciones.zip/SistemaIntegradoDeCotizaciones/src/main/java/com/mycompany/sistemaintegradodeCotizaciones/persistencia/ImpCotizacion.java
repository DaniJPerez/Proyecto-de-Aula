/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.sistemaintegradodeCotizaciones.persistencia;

import com.mycompany.sistemaintegradodeCotizaciones.entidades.Cotizacion;

/**
 *
 * @author f
 */
public interface ImpCotizacion {
    public boolean agregarCotizacion(Cotizacion a);
    public boolean eliminarCotizacion(Cotizacion a);
    public Cotizacion buscarCotizacion(int a);
    public Cotizacion obtenerCotizacion(Cotizacion a);
    
}
