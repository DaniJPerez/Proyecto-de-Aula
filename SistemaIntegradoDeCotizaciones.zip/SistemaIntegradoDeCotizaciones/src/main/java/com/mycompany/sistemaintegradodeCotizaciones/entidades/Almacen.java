/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaintegradodeCotizaciones.entidades;
import java.util.ArrayList;

public class Almacen {
    private int idAlmacen;
    private String nombre;
    private String ubicacion;
    private ArrayList<Cotizacion> cotizaciones;
    public Almacen() {
        this.cotizaciones=new ArrayList();
    }

    public Almacen(int idAlmacen, String nombre, String ubicacion) {
        this();
        this.idAlmacen = idAlmacen;
        this.nombre = nombre;
        this.ubicacion = ubicacion;
    }

    public int getIdAlmacen() {
        return idAlmacen;
    }

    public void setIdAlmacen(int idAlmacen) {
        this.idAlmacen = idAlmacen;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    public ArrayList<Cotizacion> getCotizaciones() {
        return cotizaciones;
    }

    public void setCotizaciones(ArrayList<Cotizacion> cotizaciones) {
        this.cotizaciones = cotizaciones;
    }

    @Override
    public String toString() {
        return "Almacen{" + "idAlmacen=" + idAlmacen + ", nombre=" + nombre + ", ubicacion=" + ubicacion + ", cotizaciones=" + cotizaciones + '}';
    }
    public void agregarCotizacion(Cotizacion cotizacion){
        this.cotizaciones.add(cotizacion);
    }
    
    public boolean registrar(){
        return false;
    }
    }
