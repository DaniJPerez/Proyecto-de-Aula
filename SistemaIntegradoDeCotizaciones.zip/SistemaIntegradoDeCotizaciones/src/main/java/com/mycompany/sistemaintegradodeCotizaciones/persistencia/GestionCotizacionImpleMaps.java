/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaintegradodeCotizaciones.persistencia;

import com.mycompany.sistemaintegradodeCotizaciones.entidades.Cotizacion;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Jose Lopez
 */
public class GestionCotizacionImpleMaps implements ImpCotizacion{
    private Map<Integer, Cotizacion> registroCotizacion;
       
    public GestionCotizacionImpleMaps() {
        this.registroCotizacion = new HashMap();
    }

    public Map<Integer, Cotizacion> getRegistroCotizacion() {
        return registroCotizacion;
    }

    public void setRegistroCotizacion(Map<Integer, Cotizacion> registroCotizacion) {
        this.registroCotizacion = registroCotizacion;
    }

    @Override
    public String toString() {
        return "GestionCotizacion{" + "cotiza=" + registroCotizacion + '}';
    }

     public boolean agregarCotizacion(Cotizacion a) {
        this.registroCotizacion.put(a.getIdCotizacion(), a);
        return true;
    }

    public Cotizacion buscarCotizacion(int id) {
        for(Map.Entry<Integer,Cotizacion>coti:this.registroCotizacion.entrySet()){
            if(coti.getKey()==id){
                return (Cotizacion)coti;
            }
       }
       return null;
    }

    public boolean eliminarCotizacion(Cotizacion a) {
         return this.registroCotizacion.remove(a.getIdCotizacion(), a);
    }

   
    public ArrayList<Cotizacion> obtenerCotizacion(Cotizacion a) {
        return  new ArrayList(this.registroCotizacion.values());
        
    }
    
}
