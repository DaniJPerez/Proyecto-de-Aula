/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaintegradodeCotizaciones.dto;

import com.mycompany.sistemaintegradodeCotizaciones.entidades.DetalleCotizacion;
import com.mycompany.sistemaintegradodeCotizaciones.entidades.Producto;
import com.mycompany.sistemaintegradodeCotizaciones.entidades.ProductoUnitario;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;

/**
 *
 * @author f
 */
public class DetalleCotizacionesDto {
    private SimpleIntegerProperty idDetalleCotizacion;
    private ProductoDto producto;
    private SimpleIntegerProperty cantidad;

    public DetalleCotizacionesDto(DetalleCotizacion odj) {
        this.idDetalleCotizacion = new SimpleIntegerProperty(odj.getIdDetalleCotizacion());
        this.producto = new ProductoUnitarioDto(odj.getProducto());
        this.cantidad = new SimpleIntegerProperty(odj.getCantidad());
    }
    
    public int getIdDetalleCotizacion() {
        return this.idDetalleCotizacion.get();
    }

    public void setIdDetalleCotizacion(int idDetalleCotizacion) {
        this.idDetalleCotizacion.set(idDetalleCotizacion);
    }

    public ProductoDto getProducto() { 
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto.setIdProducto(producto.getIdProducto());
        this.producto.setIdProducto(producto.getIdProducto());
        this.producto.setNombre(producto.getNombre());
    }

    public int getCantidad() {
        return cantidad.get();
    }

    public void setCantidad(int cantidad) {
        this.cantidad.set(cantidad);
    }
    
    
}
