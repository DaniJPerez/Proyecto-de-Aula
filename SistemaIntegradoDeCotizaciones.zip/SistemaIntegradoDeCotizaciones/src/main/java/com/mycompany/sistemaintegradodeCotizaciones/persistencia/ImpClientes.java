/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.sistemaintegradodeCotizaciones.persistencia;

import com.mycompany.sistemaintegradodeCotizaciones.entidades.Cliente;

/**
 *
 * @author f
 */
public interface ImpClientes {
    public boolean agregarCliente(Cliente a);
    public boolean eliminarCliente(Cliente a);
    public Cliente buscarCliente(int a);
    public Cliente obtenerCliente(Cliente a);
       
    
}
