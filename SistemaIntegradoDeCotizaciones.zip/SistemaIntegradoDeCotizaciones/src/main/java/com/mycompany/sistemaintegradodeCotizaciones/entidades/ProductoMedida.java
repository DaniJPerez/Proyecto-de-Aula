/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaintegradodeCotizaciones.entidades;

/**
 *
 * @author Jose Lopez
 */
public class ProductoMedida extends Producto {
      
      private double metro;

    public ProductoMedida() {
        super();
    }

    public ProductoMedida(double metro, int idProducto, String nombre, double precio, String descripcion) {
        super(idProducto, nombre, precio, descripcion);
        this.metro = metro;
    }
    
    public double getMetro() {
        return  metro;
    }

    public void setMetro(int metro) {
        this.metro = metro;
    }
    
    public double calcularPrecio(double metro){
        return super.getPrecio()*metro;
    }
}
