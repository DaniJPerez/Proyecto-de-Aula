/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaintegradodeCotizaciones.logica;

import com.mycompany.sistemaintegradodeCotizaciones.entidades.Cotizacion;
import com.mycompany.sistemaintegradodeCotizaciones.persistencia.ImpCotizacion;

/**
 *
 * @author f
 */
public class LogicaCotizacion {
    private ImpCotizacion datCotizacion;
    
    
    public boolean agregarCotizacion(Cotizacion a)throws IllegalStateException,IllegalArgumentException{
        return this.datCotizacion.agregarCotizacion(a);
    }
    
    public boolean eliminarCotizacion(Cotizacion a)throws IllegalStateException,IllegalArgumentException{
        return this.datCotizacion.eliminarCotizacion(a);
    }
    
    public Cotizacion buscarCotizacion(int a)throws IllegalStateException,IllegalArgumentException{
        return this.datCotizacion.buscarCotizacion(a);
    }
    
    public Cotizacion obtenerCotizacion(Cotizacion a)throws IllegalStateException,IllegalArgumentException{
        return this.datCotizacion.obtenerCotizacion(a);
    }
    
}
