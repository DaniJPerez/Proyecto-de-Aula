/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaintegradodeCotizaciones.entidades;

/**
 *
 * @author Jose Lopez
 */
public class Gerente extends Usuario {
        private String puesto;
    public Gerente() {
        super();
    }

    public Gerente(String puesto, int idUsuario, String nombre) {
        super(idUsuario, nombre);
        this.puesto = puesto;
    }

    public String getPuesto() {
        return puesto;
    }

    public void setPuesto(String puesto) {
        this.puesto = puesto;
    }

    @Override
    public String toString() {
        return "Gerente{" + "puesto=" + puesto + '}';
    }
    public void gestionarInventario(){
        
    }
    public void actualizarInfoEmpleado(){
        
    }
    
   /* public boolean agregarProducto(InventarioImpleMaps e){
      return e.agregar();
    }*/
    
    
}
