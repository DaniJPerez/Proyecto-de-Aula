/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaintegradodeCotizaciones.persistencia;

import com.mycompany.sistemaintegradodeCotizaciones.entidades.Usuario;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Jose Lopez
 */
public class GestionUsuarioImpMaps implements ImpUsuario{
    private Map<Integer, Usuario> registroUsuario;

    public Map<Integer, Usuario> getRegistroUsuario() {
        return registroUsuario;
    }

    public void setRegistroUsuario(Map<Integer, Usuario> registroUsuario) {
        this.registroUsuario = registroUsuario;
    }

    @Override
    public String toString() {
        return "GestionUsuario{" + "person=" + registroUsuario + '}';
    }
       
    public GestionUsuarioImpMaps() {
        this.registroUsuario = new HashMap();
    }

    @Override
     public boolean agregarUsuario(Usuario a) throws IllegalArgumentException{
         if(a==null)
            throw new IllegalArgumentException("No se puede registrar un Usuario NULL");
        
        if(a.getNombre().isBlank())
            throw new IllegalArgumentException("El primer nombre del usuario no puede ser NULL");
        
        if(a.getPassword().isBlank())
            throw new IllegalArgumentException("El PASSWORD no puede ser NULL");
        
        for(Map.Entry<Integer,Usuario>usuario:this.registroUsuario.entrySet()){
            if(usuario.getValue().getIdUsuario()==a.getIdUsuario()){
                 throw new IllegalStateException("El usuario "+a.getNombre()+ " No esta disponible");
            }
       }
        
        this.registroUsuario.put(a.getIdUsuario(), a);
        return true;
    }

    @Override
    public Usuario buscarUsuario(int id) throws IllegalArgumentException{
        Usuario user=null;
        for(Map.Entry<Integer,Usuario>usuario:this.registroUsuario.entrySet()){
            if(usuario.getKey()==id){
                user= (Usuario)usuario;
            }
       }
        if(user==null)
            throw new IllegalArgumentException("no existe ese Usuario");
        return user;
    }

    @Override
    public boolean eliminarUsuario(Usuario a)throws IllegalArgumentException {
        if(a==null){
            throw new IllegalArgumentException("No se puede eliminar un Usuario que no existe");
        }
         return this.registroUsuario.remove(a.getIdUsuario(), a);
    }

   
    @Override
    public Usuario obtenerUsuario(Usuario a) throws IllegalArgumentException{
        Usuario user=null;
        for(Map.Entry<Integer,Usuario>usuario:this.registroUsuario.entrySet()){
            if(usuario.equals(a)){
                user=(Usuario)usuario;
            }
       }
       if(user==null)
           throw new IllegalArgumentException("El usuario es inexistente ");
        return user;
    }
    
}
