/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaintegradodeCotizaciones.persistencia;

import com.mycompany.sistemaintegradodeCotizaciones.entidades.Usuario;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Jose Lopez
 */
public class GestionUsuarioImpMaps implements ImpUsuario{
    private Map<Integer, Usuario> registroUsuario;

    public Map<Integer, Usuario> getRegistroUsuario() {
        return registroUsuario;
    }

    public void setRegistroUsuario(Map<Integer, Usuario> registroUsuario) {
        this.registroUsuario = registroUsuario;
    }

    @Override
    public String toString() {
        return "GestionUsuario{" + "person=" + registroUsuario + '}';
    }
       
    public GestionUsuarioImpMaps() {
        this.registroUsuario = new HashMap();
    }

     public boolean agregarUsuario(Usuario a) {
        this.registroUsuario.put(a.getIdUsuario(), a);
        return true;
    }

    public Usuario buscarUsuario(int id) {
        for(Map.Entry<Integer,Usuario>usuario:this.registroUsuario.entrySet()){
            if(usuario.getKey()==id){
                return (Usuario)usuario;
            }
       }
       return null;
    }

    public boolean eliminarUsuario(Usuario a) {
         return this.registroUsuario.remove(a.getIdUsuario(), a);
    }

   
    public ArrayList<Usuario> obtenerUsuario(int id) {
        return  new ArrayList(this.registroUsuario.values());
        
    }
    
}
