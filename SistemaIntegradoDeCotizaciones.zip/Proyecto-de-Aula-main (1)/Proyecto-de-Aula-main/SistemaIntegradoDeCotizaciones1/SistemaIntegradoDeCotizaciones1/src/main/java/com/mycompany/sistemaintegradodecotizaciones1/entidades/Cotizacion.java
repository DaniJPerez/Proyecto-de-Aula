/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaintegradodeCotizaciones1.entidades;
import java.util.ArrayList;
import java.time.LocalDate;
/**
 *
 * @author ESTUDIANTE
 */
public class Cotizacion {
  private int idCotizacion;
  private LocalDate fecha;
  private String estado;
  private double subtotal;
  private Cliente cliente;
  private ArrayList<DetalleCotizacion> detalle;
  private Empleado empleado;
  private Almacen almacen;
  
    public Cotizacion() {
        this.detalle=new ArrayList();
    }

    public Cotizacion(int idCotizacion, LocalDate fecha, String estado, Empleado empleado, Almacen almacen) {
        this();
        this.idCotizacion = idCotizacion;
        this.fecha =LocalDate.now();
        this.estado = estado;
        this.empleado = empleado;
        this.almacen = almacen;
    }
    public int getIdCotizacion() {
        return idCotizacion;
    }

    public void setIdCotizacion(int idCotizacion) {
        this.idCotizacion = idCotizacion;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public double getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(double subtotal) {
        this.subtotal = subtotal;
    }

    public ArrayList<DetalleCotizacion> getDetalle() {
        return detalle;
    }

    public void setDetalle(ArrayList<DetalleCotizacion> detalle) {
        this.detalle = detalle;
    }
    
    public Empleado getEmpleado() {
        return empleado;
    }

    public void setEmpleado(Empleado empleado) {
        this.empleado = empleado;
    }

    public Almacen getAlmacen() {
        return almacen;
    }
    
    public void setAlmacen(Almacen almacen) {
        this.almacen = almacen;
    }
    
    public Cliente getCliente(){
        return cliente;
    }
    
    public void setCliente(Cliente cliente){
        this.cliente=cliente;
    }
    
    @Override
    public String toString() {
        return "Cotizacion{" + "idCotizacion=" + idCotizacion + ", fecha=" + fecha + ", estado=" + estado + ", total=" + subtotal + ", cliente=" + cliente + ", Detalle=" + detalle + ", empleado=" + empleado + ", almacen=" + almacen + '}';
    }
    
    public boolean añadirProducto(Producto a) throws IllegalArgumentException{
        DetalleCotizacion produtDetalle=new DetalleCotizacion();
        for(DetalleCotizacion e: this.detalle){
            if(e.getProducto().equals(a))
                produtDetalle.setProducto(a);
        }
        if(produtDetalle==null)
            throw new IllegalArgumentException("No existe ese producto en el inventario");
        produtDetalle.setProducto(a);
        
        return  this.detalle.add(produtDetalle);
    }
    
    public String actualizarEstado(String estado){
        return this.estado=estado;
    }
    public double calcularTotal(DetalleCotizacion a){
        this.subtotal=a.calcularsubTotal(a.getProducto());
        return this.subtotal*0.19;
        
    }
    
    public boolean añadirDetalle(DetalleCotizacion e){
        return this.detalle.add(e);
    }
    
    public DetalleCotizacion buscarDetalle(int id){
       for(DetalleCotizacion a: this.detalle){
           if(a.getIdDetalleCotizacion()==id){
               return a;
           }
       }
       return null;
   }
    
}

