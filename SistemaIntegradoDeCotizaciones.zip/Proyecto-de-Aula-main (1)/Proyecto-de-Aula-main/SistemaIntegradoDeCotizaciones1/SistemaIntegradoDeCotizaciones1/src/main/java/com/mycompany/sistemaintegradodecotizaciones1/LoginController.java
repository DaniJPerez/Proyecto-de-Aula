package com.mycompany.sistemaintegradodecotizaciones1;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */

import com.mycompany.sistemaintegradodeCotizaciones1.logica.LogicaUsuario;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author f
 */
public class LoginController implements Initializable {

    @FXML private TextField  txtUserName;
    @FXML private PasswordField txtPassword;
    @FXML private Button btnLogin;
    private LogicaUsuario logicaUsuario= new LogicaUsuario();
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
    }    
    
    @FXML
    public void clickBtnLogin(ActionEvent event)throws IOException{
        String username=this.txtUserName.getText();
        String password= this.txtPassword.getText();
        
        if(this.logicaUsuario.Login(username, password)){
            App.setNewScene("PantallaPrincipal");
        }
        else{
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Mensaje de Login");
            alert.setHeaderText("Informacion de credenciales");
            alert.setContentText("La informacion sublida es inconrrecta "
            +"intente de nuevo ");
            alert.show();
        }
    }
}
