/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaintegradodeCotizaciones1.dto;

import com.mycompany.sistemaintegradodeCotizaciones1.entidades.ProductoMedida;
import javafx.beans.property.SimpleDoubleProperty;

/**
 *
 * @author f
 */
public class ProductoMedidaDto extends ProductoDto{
    
    private SimpleDoubleProperty metro;

    public ProductoMedidaDto(ProductoMedida odj) {
        super(odj);
        this.metro= new SimpleDoubleProperty(odj.getMetro());
        
    }

    public double getMetro() {
        return metro.get();
    }

    public void setMetro(double metro) {
        this.metro.set(metro);
    }
    
    
}
