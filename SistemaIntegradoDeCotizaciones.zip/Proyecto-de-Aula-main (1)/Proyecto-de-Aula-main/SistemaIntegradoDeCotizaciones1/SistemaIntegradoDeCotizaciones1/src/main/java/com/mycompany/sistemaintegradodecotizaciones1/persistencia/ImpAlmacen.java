/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.sistemaintegradodeCotizaciones1.persistencia;

import com.mycompany.sistemaintegradodeCotizaciones1.entidades.Almacen;

/**
 *
 * @author f
 */
public interface ImpAlmacen {
    public boolean agregarAlmacen(Almacen a);
    public boolean eliminarAlmacen(Almacen a);
    public Almacen buscarAlmacen(int a);
    public Almacen obtenerAlmacen(Almacen a);
}
