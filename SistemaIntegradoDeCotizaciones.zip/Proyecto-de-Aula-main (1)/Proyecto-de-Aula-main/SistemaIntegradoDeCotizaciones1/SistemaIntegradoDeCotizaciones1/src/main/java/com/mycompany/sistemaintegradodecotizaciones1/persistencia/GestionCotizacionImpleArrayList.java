/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaintegradodeCotizaciones1.persistencia;


import com.mycompany.sistemaintegradodeCotizaciones1.entidades.Cotizacion;
import java.util.ArrayList;

/**
 *
 * @author f
 */
public class GestionCotizacionImpleArrayList implements ImpCotizacion{
    private ArrayList<Cotizacion> registroCotizacion;

    public GestionCotizacionImpleArrayList() {
        this.registroCotizacion=new ArrayList();
    }

    public ArrayList<Cotizacion> getRegistroCotizacion() {
        return registroCotizacion;
    }

    public void setRegistroCotizacion(ArrayList<Cotizacion> registroCotizacion) {
        this.registroCotizacion = registroCotizacion;
    }

    @Override
    public String toString() {
        return "GestionCotizacionImpleArrayList{" + "registroCotizacion=" + registroCotizacion + '}';
    }
    
    public boolean agregarCotizacion(Cotizacion a){
        return this.registroCotizacion.add(a);
    }
    
    public boolean eliminarCotizacion(Cotizacion a){
        return this.registroCotizacion.add(a);
    }
    
    public Cotizacion buscarCotizacion(int a){
        for(Cotizacion e : this.registroCotizacion){
            if(e.getIdCotizacion()==a){
                return e;
            }
        }
        return null;
    }
    
    public Cotizacion obtenerCotizacion(Cotizacion a){
        for(Cotizacion e : this.registroCotizacion){
            if(a.equals(e)){
                return e;
            }
        }
        return null;
    }
    
}
