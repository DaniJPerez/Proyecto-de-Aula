/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaintegradodeCotizaciones1.persistencia;

import com.mycompany.sistemaintegradodeCotizaciones1.entidades.Almacen;
import java.util.ArrayList;

/**
 *
 * @author f
 */
public class GestionAlmacenImpleArrayList implements ImpAlmacen{
    private ArrayList<Almacen> registroAlmacen;

    public GestionAlmacenImpleArrayList() {
        this.registroAlmacen=new ArrayList();
    }

    public ArrayList<Almacen> getRegistroAlmacen() {
        return registroAlmacen;
    }

    public void setRegistroAlmacen(ArrayList<Almacen> registroAlmacen) {
        this.registroAlmacen = registroAlmacen;
    }

    @Override
    public String toString() {
        return "GestionAlamacenImpleArrayList{" + "registroAlmacen=" + registroAlmacen + '}';
    }
    
    @Override
    public boolean agregarAlmacen(Almacen a){
        return this.registroAlmacen.add(a);
    }
    
    @Override
    public boolean eliminarAlmacen(Almacen a){
        return this.registroAlmacen.remove(a);
    }
    
    @Override
    public Almacen buscarAlmacen(int a){
        for(Almacen e : this.registroAlmacen){
            if(e.getIdAlmacen()==a){
                return e;
            }
        }
        return null;
    }
    
    @Override
    public Almacen obtenerAlmacen(Almacen a){
         for(Almacen e : this.registroAlmacen){
            if(a.equals(e)){
                return e;
            }
        }
        return null;
    }
}
