/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaintegradodeCotizaciones1.logica;

/**
 *
 * @author f
 */
public class SingletonInventario {
    private static LogicaInventario mode;
    
    public static LogicaInventario getInstancia(){
        if(mode==null){
            mode = new LogicaInventario();
            return mode;
        }
        else{
            return mode;
        }
    }
}
