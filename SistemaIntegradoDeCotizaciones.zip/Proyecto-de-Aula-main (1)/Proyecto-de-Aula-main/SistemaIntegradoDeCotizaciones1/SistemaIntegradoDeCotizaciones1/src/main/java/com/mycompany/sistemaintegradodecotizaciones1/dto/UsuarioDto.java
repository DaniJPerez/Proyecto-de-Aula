/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaintegradodeCotizaciones1.dto;

import com.mycompany.sistemaintegradodeCotizaciones1.entidades.Usuario;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

/**
 *
 * @author f
 */
public abstract class UsuarioDto {
    private SimpleIntegerProperty idUsuario;
    private SimpleStringProperty nombre;
    private SimpleStringProperty password;

    public UsuarioDto(Usuario odj) {
        this.idUsuario = new SimpleIntegerProperty(odj.getIdUsuario());
        this.nombre = new SimpleStringProperty(odj.getNombre());
        this.password = new SimpleStringProperty(odj.getPassword());
    }

    public int getIdUsuario() {
        return idUsuario.get();
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario.set(idUsuario);
    }

    public String getNombre() {
        return nombre.get();
    }

    public void setNombre(String nombre) {
        this.nombre.get();
    }

    public String getPassword() {
        return password.get();
    }

    public void setPassword(String password) {
        this.password.set(password);
    }
    
    
}
