/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

import persistencia.Inventario;

/**
 *
 * @author Jose Lopez
 */
public class ProductoMedida extends Producto {
       private double precioPorMetro;
      private double metro;

    public ProductoMedida() {
        super();
    }

    public ProductoMedida(int idProducto,double precioPorMetro, double metro, String nombre, String descripcion) {
        super(idProducto, nombre, descripcion);
        this.precioPorMetro = precioPorMetro;
        this.metro = metro;
    }
      
    public double getPrecioPorMetro() {
        return precioPorMetro;
    }

    public void setPrecioPorMetro(double precioPorMetro) {
        this.precioPorMetro = precioPorMetro;
    }

    public double getMetro() {
        return  metro;
    }

    public void setMetro(int metro) {
        this.metro = metro;
    }
     @Override
    public double calcularPrecio() {
        double precio=this.precioPorMetro*this.metro;
    return precio;
    }
}
