/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;
import persistencia.GestionClientes;
import java.util.ArrayList;
import java.time.LocalDate;
/**
 *
 * @author ESTUDIANTE
 */
public class Cotizacion {
  private int idCotizacion;
  private LocalDate fecha;
  private String estado;
  private double subtotal;
  private GestionClientes clientes;
  private ArrayList<DetalleCotizacion> detalle;
  private Empleado empleado;
  private Almacen almacen;
  
    public Cotizacion() {
        this.detalle=new ArrayList();
    }

    public Cotizacion(int idCotizacion, LocalDate fecha, String estado, Empleado empleado, Almacen almacen) {
        this();
        this.idCotizacion = idCotizacion;
        this.fecha = fecha;
        this.estado = estado;
        this.empleado = empleado;
        this.almacen = almacen;
    }
    public int getIdCotizacion() {
        return idCotizacion;
    }

    public void setIdCotizacion(int idCotizacion) {
        this.idCotizacion = idCotizacion;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public double getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(double subtotal) {
        this.subtotal = subtotal;
    }

    public ArrayList<DetalleCotizacion> getDetalle() {
        return detalle;
    }

    public void setDetalle(ArrayList<DetalleCotizacion> detalle) {
        this.detalle = detalle;
    }
    
    public Empleado getEmpleado() {
        return empleado;
    }

    public void setEmpleado(Empleado empleado) {
        this.empleado = empleado;
    }

    public Almacen getAlmacen() {
        return almacen;
    }

    public void setAlmacen(Almacen almacen) {
        this.almacen = almacen;
    }

    @Override
    public String toString() {
        return "Cotizacion{" + "idCotizacion=" + idCotizacion + ", fecha=" + fecha + ", estado=" + estado + ", total=" + subtotal + ", clientes=" + clientes + ", Detalle=" + detalle + ", empleado=" + empleado + ", almacen=" + almacen + '}';
    }
    
     public boolean generarCotizacion(DetalleCotizacion e){
        return this.detalle.add(e);
        
    }
    public String actualizarEstado(String estado){
        return null;
    }
    public double calcularTotal(DetalleCotizacion a){
        this.subtotal=a.calcularsubTotal(a.getProducto());
        return this.subtotal*0.19;
        
    }

    public boolean generarCotizacion(Producto producto) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    public boolean añadirDetalle(DetalleCotizacion e){
        return this.detalle.add(e);
    }
    
    public DetalleCotizacion buscarDetalle(int id){
       for(DetalleCotizacion a: this.detalle){
           if(a.getIdDetalleCotizacion()==id){
               return a;
           }
       }
       return null;
   }
    
}

