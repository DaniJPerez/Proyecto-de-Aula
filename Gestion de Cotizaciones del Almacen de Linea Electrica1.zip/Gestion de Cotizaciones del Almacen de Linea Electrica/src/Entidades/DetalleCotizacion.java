/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

import java.util.ArrayList;


public class DetalleCotizacion {
    private int idDetalleCotizacion;
    private Producto producto;
    private double precio;
    private int cantidad;

    public DetalleCotizacion() {
    }

    public DetalleCotizacion(int idDetalleCotizacion,ProductoMedida producto, double precioMedida, int cantidad) {
        this.idDetalleCotizacion= idDetalleCotizacion;
        this.producto = new ProductoMedida();
        this.precio = precioMedida;
        this.cantidad = cantidad;
        
    }
    
     public DetalleCotizacion(int idDetalleCotizacion,ProductoUnicitario producto, int cantidad) {
        this.idDetalleCotizacion=idDetalleCotizacion;
        this.producto = new ProductoUnicitario();
        this.cantidad = cantidad;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public double getPrecioUnitario() {
        return precio;
    }

    public void setPrecioUnitario(double precio) {
        this.precio = precio;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public int getIdDetalleCotizacion() {
        return idDetalleCotizacion;
    }

    public void setIdDetalleCotizacion(int idDetalleCotizacion) {
        this.idDetalleCotizacion = idDetalleCotizacion;
    }
    
   public double calcularsubTotal(Producto a){
        return a.calcularPrecio();
    }
   
   public double calcularsubTotal(ProductoMedida a){
        return a.calcularPrecio();
    }
   
   public ArrayList<Producto> obtenerProducto(Producto e){
       return e.buscarProducto(this.producto.getIdProducto());
   }
   
   public boolean AñadirProducto(Cotizacion e){
       return e.generarCotizacion(this.producto);
   }
   
   public DetalleCotizacion añadirDeetalle(int idDetalle, ProductoUnicitario productos, int cantidad){
       return new DetalleCotizacion(idDetalle,productos, cantidad);
   }
   
   
}
