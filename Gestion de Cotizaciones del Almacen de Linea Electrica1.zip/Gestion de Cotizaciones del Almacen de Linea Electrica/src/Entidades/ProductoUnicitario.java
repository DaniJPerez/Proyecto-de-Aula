/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

import logic.LogicaReal;
import persistencia.Inventario;

/**
 *
 * @author Jose Lopez
 */
public class ProductoUnicitario extends Producto {
      private double preciouni;
      LogicaReal logica =new LogicaReal();
    public ProductoUnicitario() {
        super();
    }
    
    public ProductoUnicitario(int idProducto,String nombre,double preciouni,  String descripcion) {
        super(idProducto, nombre, descripcion);
        this.preciouni = preciouni;
    }
    public double getPreciouni() {
        return preciouni;
    }

    public void setPreciouni(double preciouni) {
        this.preciouni = preciouni;
    } 
    @Override
    public double calcularPrecio() {
    return this.getPreciouni();
    }
    
    public Producto buscarInventario(Producto e){
        return logica.buscarProducto(e);
    }
}
