/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package persistencia;

import Entidades.Usuario;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Jose Lopez
 */
public class GestionUsuario implements RegistroElementosReales{
    private Map<Integer, Usuario> person;
       
    public GestionUsuario() {
        this.person = new HashMap();
    }

     public boolean agregar(Usuario a) {
        this.person.put(a.getIdUsuario(), a);
        return true;
    }

    public Usuario buscar(int id) {
        return this.person.get(id);
    }

    public boolean eliminar(Usuario a) {
         return this.person.remove(a.getIdUsuario(), a);
    }

   
    public ArrayList<Usuario> obtener(int id) {
        return  new ArrayList(this.person.values());
        
    }
    
}
