/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package persistencia;

import Entidades.Almacen;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Jose Lopez
 */
public class GestionAlmacen implements RegistroElementosReales{
    private Map<Integer, Almacen> almacen;
       
    public GestionAlmacen() {
        this.almacen = new HashMap();
    }

     public boolean agregar(Almacen a) {
        this.almacen.put(a.getIdAlmacen(), a);
        return true;
    }

    public Almacen buscar(int id) {
        return this.almacen.get(id);
    }

    public boolean eliminar(Almacen a) {
         return this.almacen.remove(a.getIdAlmacen(), a);
    }

   
    public ArrayList<Almacen> obtener(int codigo) {
        return  new ArrayList(this.almacen.values());
        
    }
}
