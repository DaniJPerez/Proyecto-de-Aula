/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package persistencia;

import Entidades.Cliente;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Jose Lopez
 */
public class GestionClientes implements RegistroElementosReales{
    private Map<Integer, Cliente> cliente;
       
    public GestionClientes() {
        this.cliente = new HashMap();
    }

     public boolean agregar(Cliente a) {
        this.cliente.put(a.getIdCliente(), a);
        return true;
    }

    public Cliente buscar(int id) {
        return this.cliente.get(id);
    }

    public boolean eliminar(Cliente a) {
         return this.cliente.remove(a.getIdCliente(), a);
    }

   
    public ArrayList<Cliente> obtener(int id) {
        return  new ArrayList(this.cliente.values());
        
    }
    
    public boolean examinarExistencia(int idCliente){
        return this.cliente.containsKey(idCliente);
    }
}
