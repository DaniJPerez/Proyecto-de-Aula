/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package persistencia;

import Entidades.Producto;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;



/**
 *
 * @author Jose Lopez
 */
public class Inventario implements RegistroElementosUtopicos{
       private Map<Integer, Producto> producto;
       
    public Inventario() {
        this.producto = new HashMap();
    }

     public boolean agregar(Producto a) {
        this.producto.put(a.getIdProducto(), a);
        return true;
    }

    public Producto buscar(int id) {
        return this.producto.get(id);
    }

    public boolean eliminar(Producto a) {
         return this.producto.remove(a.getIdProducto(), a);
    }

    public ArrayList<Producto> obtener(int a) {
        return  new ArrayList(this.producto.values());
        
    }
  
    
}
