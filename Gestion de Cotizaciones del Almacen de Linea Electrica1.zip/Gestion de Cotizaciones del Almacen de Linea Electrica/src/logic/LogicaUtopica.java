/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package logic;

import Entidades.Cotizacion;
import Entidades.Producto;
import persistencia.GestionCotizacion;
import persistencia.Inventario;

/**
 *
 * @author f
 */
public class LogicaUtopica {
    private Inventario persistenciaInventario;
    private GestionCotizacion persistenciaCotizacion;

    public LogicaUtopica() {
        this.persistenciaInventario = new Inventario();
        this.persistenciaCotizacion = new GestionCotizacion();
    }
    
    public boolean registrar(Producto a){
        return persistenciaInventario.agregar(a);
    }
    
    public boolean registrar(Cotizacion a){
        return persistenciaCotizacion.agregar(a);
    }
    
    public Cotizacion buscar(Cotizacion a){
        return persistenciaCotizacion.buscar(a.getIdCotizacion());
    }
    
    public Producto buscar(Producto a){
        return persistenciaInventario.buscar(a.getIdProducto());
    }
}
