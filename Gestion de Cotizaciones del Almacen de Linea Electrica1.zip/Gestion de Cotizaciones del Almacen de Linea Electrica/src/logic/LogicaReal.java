/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package logic;

import Entidades.Almacen;
import Entidades.Cliente;
import Entidades.Cotizacion;
import Entidades.Producto;
import Entidades.Usuario;
import java.util.ArrayList;
import persistencia.GestionAlmacen;
import persistencia.GestionClientes;
import persistencia.GestionUsuario;
import persistencia.Inventario;
import persistencia.RegistroElementosReales;

/**
 *
 * @author f
 */
public class LogicaReal {
    
    private GestionAlmacen persistenciaAlmacen;
    private GestionClientes persistenciaCliente;
    private GestionUsuario persistenciaUsuario;
    private Inventario persistenciaInventario;

    public LogicaReal() {
        this.persistenciaAlmacen = new GestionAlmacen();
        this.persistenciaCliente = new GestionClientes();
        this.persistenciaUsuario = new GestionUsuario();
       
    }

    public LogicaReal(GestionAlmacen persistenciaAlmacen) {
        this.persistenciaAlmacen = new GestionAlmacen();
    }
    
    public Cotizacion registrarCotizacion(){
        return null;
    }
    public void RegistrarCliente(Cliente a) {
       persistenciaCliente.agregar(a);
    }
    
    public boolean registrarElemento(Almacen a){
        return persistenciaAlmacen.agregar(a);
    }
    
    public boolean registrarElemento(Cliente a){
        return persistenciaCliente.agregar(a);
    }
    
    public boolean registrarElemento(Usuario a){
        return persistenciaUsuario.agregar(a);
    }
    
    public Almacen buscar(Almacen a){
        return persistenciaAlmacen.buscar(a.getIdAlmacen());
    }
    
    public Usuario buscar(Usuario a){
        return persistenciaUsuario.buscar(a.getIdUsuario());
    }
    
    public Cliente buscar(Cliente a){
        return persistenciaCliente.buscar(a.getIdCliente());
    }
    
    public ArrayList<Cliente> obtenerCliente(int id){
        return persistenciaCliente.obtener(id);
    }
    
    public boolean existencia(int id){
        return this.persistenciaCliente.examinarExistencia(id);
    }
    
    public Producto buscarProducto(Producto e){
        return this.persistenciaInventario.buscar(e.getIdProducto());
    }
    
}
