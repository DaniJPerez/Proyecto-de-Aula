/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grafica;

import Entidades.Cliente;
import Entidades.Cotizacion;
import Entidades.DetalleCotizacion;
import Entidades.Producto;
import Entidades.ProductoUnicitario;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;
import logic.LogicaReal;

/**
 *
 * @author f
 */
public class Menu {
       private Scanner sn = new Scanner(System.in);
       private boolean salir=false;
       private int opcion;
       private Cliente cliente;
      public void MostrarMenu(){
          while(!this.salir){
           System.out.println("  Dios te bendiga\n       Cotizacion");
           System.out.println("           ");
           System.out.println("            Menu:");
           System.out.println("1 - Realizar una cotizacion");
           System.out.println("2 - Consultar una cotizacion");
           System.out.println("3 - Modificar una cotizacion");
           System.out.println("4 - Eliminar una cotizacion");
           System.out.println("5 - Salir");
           System.out.println("                ");
           
          try{
              this.evaluar();
           }catch(InputMismatchException e){
               System.out.println("Debes insertar un numero");
               this.sn.next();
           }
       }
      }
      
    public void evaluar(){
        System.out.println("Digite una opcion segun lo que desea realizar:");
           opcion = sn.nextInt();
           switch(opcion){
               case 1 ->{ crearCotizacion();
                   
                   
                   break;
                   }
               case 2 -> { 
                   break;
                   }
                  case 3 -> {
                   break;
                   }
               case 4 -> {
                   break;
                   }
               case 5 -> { this.salir=true;
                   break;
                   }
               default -> System.out.println("Solo numeros del 1 al 5");     
           } 
    }
    
    public void crearCotizacion(){
        System.out.println("");
        System.out.println("## 1. Crear Cotizacion ## ");
        System.out.println("__________________________");
        Cotizacion cotizacion=null;
        DetalleCotizacion detalleProductos= null;
        
        Producto productos=null;
        int oppc;
        int opc;
        boolean op=true;
       /* do{
            System.out.println("Buscar Producto ");
            System.out.println("[1] Buscar por Nombre ");
            System.out.println("[2] buscar por su Id ");
            oppc=this.sn.nextInt();
        }while(oppc!=1 && oppc!=2);
        */
       while(op){
          System.out.println("Digite el id del producto ");
        System.out.printf("%-20s: ", "id ");
        int idProducto= this.sn.nextInt(); 
          System.out.printf("%-20s: ", "Nombre Del Producto ");
        String nom=this.sn.next();
        System.out.printf("%-20s: ", "Cantidad ");
        int cantidad=this.sn.nextInt();
        System.out.printf("%-20s: ","Añada una descripcion del producto ");
        String descripcion=this.sn.next();
        //no olvide añadir el pricio como argumento
        
        productos= new ProductoUnicitario(idProducto,nom,180000.00,descripcion);
        System.out.println("________________________");
        System.out.println("Confirmar Coizacion");
        System.out.println("Si[1] No[2] ");
        opc=this.sn.nextInt();
        Integer noDetalleCotizacion=0;
        noDetalleCotizacion=1+noDetalleCotizacion;
        if(opc==1)
            
            detalleProductos.añadirDeetalle(noDetalleCotizacion,(ProductoUnicitario) productos,cantidad);
           cotizacion.añadirDetalle(detalleProductos);
           System.out.println("¿Quiere añadir aun otro producto? Si[1] No[2] ");
           int opp=this.sn.nextInt();
           if(opp==1)
               op=true;
           else
               op=false;
       }
       
        System.out.printf("_________________________ ");
        System.out.printf("%-20s: ", "id Usuario ");
        int idCliente=this.sn.nextInt();
        LogicaReal logica=new LogicaReal();
        if(logica.existencia(idCliente))
            logica.obtenerCliente(idCliente);
        else{
            System.out.println("Cliente no añadido ");
            System.out.println("¿ Quieres añadirlo ? " );
            do{
                System.out.println("Si [1]  No [2]");
                opc=this.sn.nextInt();
            }while(opc!=1 && opc!=2);
            if(opc==1){
                System.out.println(" _____________________");
                System.out.printf("%-20s " ,"Digite el Id Nacional");
                idCliente=this.sn.nextInt();
                System.out.println("______________________");
                System.out.printf("%-20s ","Digite el Nombre del Cliente");
                String nombre = this.sn.next();
                String direccion=this.sn.next();
                System.out.printf("%-20s: ","Digite el telefono del Cliente");
                double telefono=this.sn.nextDouble();
                System.out.println("Registrar Cliente ");
                System.out.println("Confirmar Si[1] No[2] ");
                do{
                opc=this.sn.nextInt();
                }while (opc!=1 && opc!=2);
                if(opc==1)
                    cliente=new Cliente(idCliente, nombre, direccion, telefono);
                else
                    idCliente=111111;//id Del Almacen
                
                logica.obtenerCliente(idCliente);
                
            }
        }
        cotizacion=new Cotizacion();
        
    }
    
    
    
  }

  
    
