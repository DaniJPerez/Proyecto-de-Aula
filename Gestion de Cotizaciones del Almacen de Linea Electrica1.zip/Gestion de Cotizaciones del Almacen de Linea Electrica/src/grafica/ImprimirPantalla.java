/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grafica;

import Entidades.Cotizacion;

/**
 *
 * @author f
 */
public class ImprimirPantalla {
    private Cotizacion cotizacion= new Cotizacion();

    public ImprimirPantalla() {
    }

    @Override
    public String toString() {
        return cotizacion.toString();
    }
    
    
}
