/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaintegradodeCotizaciones1.logica;

/**
 *
 * @author f
 */
public class SingletonUsuario {
    private static LogicaUsuario mode;
    
    public static LogicaUsuario getInstancia(){
        if(mode==null){
            mode = new LogicaUsuario();
            return mode;
        }
        else{
            return mode;
        }
    }
}
