/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaintegradodeCotizaciones1.logica;

import com.mycompany.sistemaintegradodeCotizaciones1.entidades.Cliente;
import com.mycompany.sistemaintegradodeCotizaciones1.persistencia.ImpClientes;
import java.util.ArrayList;

/**
 *
 * @author f
 */
public class LogicaCliente {
    private ImpClientes datClientes;
    
    public boolean agregarCliente(Cliente a)throws IllegalStateException,IllegalArgumentException{
        return this.datClientes.agregarCliente(a);
    }
    public boolean eliminarCliente(Cliente a)throws IllegalStateException,IllegalArgumentException{
        return this.datClientes.eliminarCliente(a);
    }
    public Cliente buscarCliente(int a)throws IllegalStateException,IllegalArgumentException{
        return this.datClientes.buscarCliente(a);
    }
    public Cliente obtenerCliente(Cliente a)throws IllegalStateException,IllegalArgumentException{
        return this.datClientes.obtenerCliente(a);
    }
       
    
}
