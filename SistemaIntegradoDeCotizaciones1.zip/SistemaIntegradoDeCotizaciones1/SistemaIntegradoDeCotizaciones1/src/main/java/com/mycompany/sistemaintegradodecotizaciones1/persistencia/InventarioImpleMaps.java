/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaintegradodeCotizaciones1.persistencia;

import com.mycompany.sistemaintegradodeCotizaciones1.entidades.Producto;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author f
 */
public class InventarioImpleMaps implements ImpInventario{
    private Map<Integer, Producto> registroProducto;
       
    public InventarioImpleMaps() {
        this.registroProducto = new HashMap();
    }

    public Map<Integer, Producto> getRegistroProducto() {
        return registroProducto;
    }

    public void setRegistroProducto(Map<Integer, Producto> registroProducto) {
        this.registroProducto = registroProducto;
    }

    @Override
    public String toString() {
        return "InventarioImpleMaps{" + "producto=" + registroProducto + '}';
    }

    @Override
     public boolean agregarProducto(Producto a) throws IllegalArgumentException{
         if(a==null)
            throw new IllegalArgumentException("No es Posible registrar un Producto con valor Nulo ");
        if(a.getDescripcion().isBlank())
            throw new IllegalArgumentException("El producto no tiene registrada la descripcion ");
        if(a.getPrecio()<0)
            throw new IllegalArgumentException("El producto no puede tener un valor menor a cero ");
        if(a.getNombre().length()==0)
            throw new IllegalArgumentException("El producto debe tener un nombre inscrito ");
        
        this.registroProducto.put(a.getIdProducto(), a);
        return true;
    }

    @Override
    public Producto buscarProducto(int id) throws IllegalArgumentException{
        Producto product=null;
        for(Map.Entry<Integer,Producto>producto:this.registroProducto.entrySet()){
            if(producto.getKey()==id){
                 product=(Producto) producto;
            }
       }
       return product;
    }

    @Override
    public boolean eliminarProducto(Producto a) throws IllegalArgumentException{
        if(a==null)
            throw new IllegalArgumentException("No hay prodcto que eliminar ");
         return this.registroProducto.remove(a.getIdProducto(), a);
    }

    @Override
    public Producto obtenerProducto(Producto a) throws IllegalArgumentException{
        Producto product=null;
        for(Map.Entry<Integer,Producto>producto:this.registroProducto.entrySet()){
            if(producto.equals(a)){
                product=(Producto)producto;
            }
       }
         if(product==null)
            throw new IllegalArgumentException("No existe ese producto ");
        return product;
    } 
    
    @Override
    public List<Producto> getListaProductos(){
        return (List<Producto>) this.registroProducto;
    }
    
    @Override
    public String buscarProducto(String a)throws IllegalArgumentException{
        String product=null;
        for(Map.Entry<Integer,Producto>producto:this.registroProducto.entrySet()){
            if(producto.getValue().getNombre().equals(a)){
                product=a;
            }
       }
         if(product==null)
            throw new IllegalArgumentException("No existe ese producto ");
        return product;
    } 
}
