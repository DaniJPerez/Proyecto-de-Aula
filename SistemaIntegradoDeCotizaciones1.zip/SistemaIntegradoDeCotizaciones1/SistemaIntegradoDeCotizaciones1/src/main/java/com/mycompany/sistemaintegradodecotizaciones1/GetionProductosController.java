/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.mycompany.sistemaintegradodecotizaciones1;

import com.mycompany.sistemaintegradodeCotizaciones1.dto.ProductoDto;
import com.mycompany.sistemaintegradodeCotizaciones1.dto.ProductoUnitarioDto;
import com.mycompany.sistemaintegradodeCotizaciones1.entidades.Producto;
import com.mycompany.sistemaintegradodeCotizaciones1.logica.LogicaInventario;
import com.mycompany.sistemaintegradodeCotizaciones1.logica.SingletonInventario;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
/**
 * FXML Controller class
 *
 * @author f
 */
public class GetionProductosController implements Initializable {
    @FXML
    private Label precioProducto, labelNombreProducto, labelDescriccionProducto;
    @FXML
    private TextField txtId;
    @FXML
    private TextField txtCantidad;
    @FXML
    private Button agregarProducto;
    @FXML
    private ListView<Producto> listProductos;
    @FXML
    private TableView<ProductoDto> tablaProductos;
    @FXML
    private TableColumn tablaId;
    @FXML
    private TableColumn tablaNombre;
    @FXML
    private TableColumn tablaPrecio;
    @FXML
    private TableColumn tablaDesccicion;
    private LogicaInventario productosMode= SingletonInventario.getInstancia();
    private ObservableList<ProductoDto> produc;
    private int cantidad= Integer.parseInt(txtCantidad.getText());
    @Override
    public void initialize(URL url, ResourceBundle rb) { // TODO
        System.out.println("Inicio ");
        this.tablaNombre.setCellValueFactory(new PropertyValueFactory("nombre"));
        this.tablaId.setCellValueFactory(new PropertyValueFactory("id"));
        this.tablaPrecio.setCellValueFactory(new PropertyValueFactory("precio"));
        this.tablaDesccicion.setCellValueFactory(new PropertyValueFactory("descriccion"));
        this.produc = FXCollections.observableArrayList();
        this.castListProducts(this.productosMode.getProducto());
        
        for(Producto p:this.productosMode.getProducto()){
            System.out.println(p);
        }
        
    }
    public void keyTypedTxTNombre(KeyEvent e){
          String str= this.txtId.getText();
          this.produc.clear();
          this.castlistProducts(this.productosMode.getProducto());
    } 
    
    public void castlistProducts(List<Producto> list){
      for(Producto p: list)  {
          ProductoDto dto=new ProductoUnitarioDto(p);
          this.produc.add(dto);
      }
    }

    private void castListProducts(List<Producto> producto) {
        for(Producto p: producto)  {
          ProductoDto dto=new ProductoUnitarioDto(p);
          this.produc.add(dto);
    }
        
  }
   
    
}

        