/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.mycompany.sistemaintegradodecotizaciones1;

import com.mycompany.sistemaintegradodeCotizaciones1.dto.ClienteDto;
import com.mycompany.sistemaintegradodeCotizaciones1.dto.CotizacionDto;
import com.mycompany.sistemaintegradodeCotizaciones1.dto.DetalleCotizacionesDto;
import com.mycompany.sistemaintegradodeCotizaciones1.dto.ProductoDto;
import com.mycompany.sistemaintegradodeCotizaciones1.dto.ProductoUnitarioDto;
import com.mycompany.sistemaintegradodeCotizaciones1.entidades.Cliente;
import com.mycompany.sistemaintegradodeCotizaciones1.entidades.Cotizacion;
import com.mycompany.sistemaintegradodeCotizaciones1.entidades.DetalleCotizacion;
import com.mycompany.sistemaintegradodeCotizaciones1.entidades.Producto;
import com.mycompany.sistemaintegradodeCotizaciones1.logica.LogicaInventario;
import com.mycompany.sistemaintegradodeCotizaciones1.logica.SingletonInventario;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author f
 */
public class CotizacionesController implements Initializable {
    @FXML
    private Button botonAgregarProducto,botonCancelar,botonEliminarProducto,botonCotizar,botonRegistrarUsuario;
    @FXML
    private ListView<DetalleCotizacion> listaProductos;
    @FXML
    private TextField texNIdentidad,texNombre,texTelefono,texDireccion,texCantidad;
    @FXML
    private TableView<DetalleCotizacionesDto> TablaListaDeProductos;
    @FXML
    private TableColumn nombre;
    @FXML
    private TableColumn precio;
    @FXML
    private TableColumn id;
    @FXML
    private TableColumn cantidad;
    
    private LogicaInventario productosMode= SingletonInventario.getInstancia();
    private ObservableList<ProductoDto> data;
    private ObservableList<DetalleCotizacionesDto> dtoD;
    
    
    @FXML
  // int a=this.texCantidad.;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        System.out.println("Ingreso");
        
        this.nombre.setCellValueFactory(new PropertyValueFactory("Nombre"));
        this.id.setCellValueFactory(new PropertyValueFactory("Precio"));
        this.precio.setCellValueFactory(new PropertyValueFactory("ID"));
        this.cantidad.setCellValueFactory(new PropertyValueFactory("Cantidad"));
        
        this.data= FXCollections.observableArrayList();
        this.castListProducts(this.productosMode.getProducto());
        
    }    
    
    public void castListProducts(List<Producto> list){
        for(Producto p: list){
            ProductoDto dto= new ProductoUnitarioDto(p);
            DetalleCotizacion deto = new DetalleCotizacion();
            deto.setProducto(p);
            DetalleCotizacionesDto Dto= new DetalleCotizacionesDto(deto);
            this.dtoD.add(Dto);
        }
        
    }
    
    public void añadirCantidad(){
        int a=0;
        a++;
        try{
            DetalleCotizacionesDto dtC= this.TablaListaDeProductos.getSelectionModel().getSelectedItem();
        int index = this.TablaListaDeProductos.getSelectionModel().getSelectedIndex();
        if(index==0){
            System.out.println("Agregar Cantidad ");
            dtC.setCantidad(Integer.parseInt(this.texCantidad.getText()));
            dtC.setIdDetalleCotizacion(a);
            this.TablaListaDeProductos.setItems(dtoD);
        }
        }catch(IllegalArgumentException ex){
            JOptionPane.showMessageDialog(null,
                        ex.getMessage(),
                        "Menssaje de error",
                        JOptionPane.ERROR_MESSAGE);
        }
        
    }
    
    public void actionBtneliminarProducto(){
        DetalleCotizacionesDto dtoSeleccionado = this.TablaListaDeProductos.getSelectionModel().getSelectedItem();
        int index = this.TablaListaDeProductos.getSelectionModel().getSelectedIndex();
        if (index >= 0) {
            try {
                int confirm = JOptionPane.showConfirmDialog(null,
                        "¿Esta seguro de elimnar el producto?",
                        "Eliminar",
                        JOptionPane.YES_NO_OPTION);
                if (confirm == 0) {
                    this.dtoD.remove(dtoSeleccionado);
                    this.data.remove(index);
                    // this.tablaProducto.setItems(this.data);

                }

            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(null,
                        ex.getMessage(),
                        "Menssaje de error",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    public void AñadirCliente(CotizacionDto coti){
    //registrar usuario
    Cliente client = new Cliente();
    client.setDirenccion(this.texDireccion.getText());
    client.setIdCliente(Integer.parseInt(this.texNIdentidad.getText()));
    client.setNombre(this.texNombre.getText());
    client.setTelefono(Double.parseDouble(this.texTelefono.getText()));
    
    ClienteDto cliente = new ClienteDto(client);
    coti.setClientes(client);
    }
    
    public void clickBtnCotizar(){
        //Se añaden todos los productos
        ArrayList<DetalleCotizacionesDto> listaDetalle;
        Cotizacion cotizacion = new Cotizacion();
        CotizacionDto coti= new CotizacionDto(cotizacion);
        
        for(DetalleCotizacionesDto a: this.dtoD){
            coti.añadirDetalle(a);   
        }
        this.AñadirCliente(coti);
    }
    
    
}
