/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaintegradodeCotizaciones1.dto;

import com.mycompany.sistemaintegradodeCotizaciones1.entidades.Empleado;
import javafx.beans.property.SimpleStringProperty;

/**
 *
 * @author f
 */
public class EmpleadoDto extends UsuarioDto{
    private SimpleStringProperty cargo;

    public EmpleadoDto(Empleado odj) {
        super(odj);
        this.cargo = new SimpleStringProperty(odj.getCargo());
    }

    public String getCargo() {
        return cargo.get();
    }

    public void setCargo(String cargo) {
        this.cargo.set(cargo);
    }
  
}
