/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaintegradodeCotizaciones1.entidades;

public class DetalleCotizacion {
    private static int ID_Detalles;
    private int idDetalleCotizacion;
    private Producto producto;
    private int cantidad;

    public DetalleCotizacion() {
    }

    public DetalleCotizacion(int idDetalleCotizacion,ProductoMedida producto, double precioMedida, int cantidad) {
        this.idDetalleCotizacion= idDetalleCotizacion;
        this.producto = new ProductoMedida();
        this.cantidad = cantidad;
        
    }
    
     public DetalleCotizacion(int idDetalleCotizacion,ProductoUnitario producto, int cantidad) {
        this.idDetalleCotizacion=idDetalleCotizacion;
        this.producto = new ProductoUnitario();
        this.cantidad = cantidad;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    
    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public int getIdDetalleCotizacion() {
        return idDetalleCotizacion;
    }

    public void setIdDetalleCotizacion(int idDetalleCotizacion) {
        this.idDetalleCotizacion = idDetalleCotizacion;
    }
    
   public double calcularsubTotal(Producto a){
        return a.calcularPrecio(this.cantidad);
    }
   
   public double calcularsubTotal(ProductoMedida a){
        return a.calcularPrecio(cantidad);
    }
   
   public Producto obtenerProducto(Producto e){
       return e.buscarInventario(e);
   }
   
   public DetalleCotizacion añadirDeetalle(int idDetalle, ProductoUnitario productos, int cantidad){
       return new DetalleCotizacion(idDetalle,productos, cantidad);
   }
   
   
}
