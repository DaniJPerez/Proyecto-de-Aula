/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaintegradodeCotizaciones1.dto;

import com.mycompany.sistemaintegradodeCotizaciones1.entidades.Almacen;
import com.mycompany.sistemaintegradodeCotizaciones1.entidades.Cliente;
import com.mycompany.sistemaintegradodeCotizaciones1.entidades.Cotizacion;
import com.mycompany.sistemaintegradodeCotizaciones1.entidades.DetalleCotizacion;
import com.mycompany.sistemaintegradodeCotizaciones1.entidades.Empleado;
import com.mycompany.sistemaintegradodeCotizaciones1.persistencia.GestionClientesImpleMaps;
import java.time.LocalDate;
import java.util.ArrayList;
import javafx.beans.property.Property;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

/**
 *
 * @author f
 */
public class CotizacionDto {
  private SimpleIntegerProperty idCotizacion;
  private LocalDate fecha;
  private SimpleStringProperty estado;
  private SimpleDoubleProperty subtotal;
  private ClienteDto clientes;
  private ArrayList<DetalleCotizacionesDto> detalle;
  private EmpleadoDto empleado;
  private AlmacenDto almacen;

    public CotizacionDto(Cotizacion odj) {
        this.idCotizacion = new SimpleIntegerProperty(odj.getIdCotizacion());
        this.fecha.with(odj.getFecha());
        this.estado = new SimpleStringProperty();
        this.subtotal = new SimpleDoubleProperty();
        this.clientes = new ClienteDto(odj.getCliente());
        this.detalle =new ArrayList();
        this.empleado = new EmpleadoDto(odj.getEmpleado());
        this.almacen = new AlmacenDto(odj.getAlmacen());
    }

    public int getIdCotizacion() {
        return idCotizacion.get();
    }

    public void setIdCotizacion(int idCotizacion) {
        this.idCotizacion.set(idCotizacion);
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha.with(fecha);
    }

    public String getEstado() {
        return estado.get();
    }

    public void setEstado(String estado) {
        this.estado.set(estado);
    }

    public SimpleDoubleProperty getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(double subtotal) {
        this.subtotal.set(subtotal);
    }

    public ClienteDto getClientes() {
        return clientes;
    }

    public void setClientes(Cliente clientes) {
        this.clientes.setDirenccion(clientes.getDirenccion());
        this.clientes.setIdCliente(clientes.getIdCliente());
        this.clientes.setNombre(clientes.getNombre());
        this.clientes.setTelefono(clientes.getTelefono());
    }

    public ArrayList<DetalleCotizacionesDto> getDetalle() {
        return detalle;
    }

    public void setDetalle(ArrayList<DetalleCotizacionesDto> detalle) {
        this.detalle = detalle;
    }

    public EmpleadoDto getEmpleado() {
        return empleado;
    }

    public void setEmpleado(EmpleadoDto empleado) {
        this.empleado = empleado;
    }

    public AlmacenDto getAlmacen() {
        return almacen;
    }

    public void setAlmacen(AlmacenDto almacen) {
        this.almacen = almacen;
    }
    
    public boolean añadirDetalle(DetalleCotizacionesDto a){
       return this.detalle.add(a);
    }
    
   
  
}
