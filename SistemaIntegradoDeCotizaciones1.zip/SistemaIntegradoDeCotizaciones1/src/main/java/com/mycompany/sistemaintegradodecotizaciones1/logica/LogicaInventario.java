/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaintegradodeCotizaciones1.logica;

import com.mycompany.sistemaintegradodeCotizaciones1.entidades.Producto;
import com.mycompany.sistemaintegradodeCotizaciones1.persistencia.ImpInventario;
import com.mycompany.sistemaintegradodeCotizaciones1.persistencia.InventarioImpleMaps;
import java.util.List;

/**
 *
 * @author f
 */
public class LogicaInventario {
    private  ImpInventario daInventario;

    public LogicaInventario() {
        this.daInventario= new InventarioImpleMaps();
    }
    
    public boolean agregarProducto(Producto a)throws IllegalStateException,IllegalArgumentException{
        return this.daInventario.agregarProducto(a);
    }
    
    public boolean eliminarProducto(Producto a)throws IllegalStateException,IllegalArgumentException{
        return this.daInventario.agregarProducto(a);
    }
    
    public Producto buscarProducto(int a)throws IllegalStateException,IllegalArgumentException{
        return this.daInventario.buscarProducto(a);
    }
    
    public Producto obtenerProducto(Producto a)throws IllegalStateException,IllegalArgumentException{
        return this.daInventario.obtenerProducto(a);
    }
    
    public List<Producto> getProducto(){
        return this.daInventario.getListaProductos();
    }
}
