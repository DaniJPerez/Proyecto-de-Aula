/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaintegradodeCotizaciones1.dto;

import com.mycompany.sistemaintegradodeCotizaciones1.entidades.Gerente;
import com.mycompany.sistemaintegradodeCotizaciones1.entidades.Usuario;
import javafx.beans.property.SimpleStringProperty;

/**
 *
 * @author f
 */
public class GerenteDto extends Usuario{
    private SimpleStringProperty puesto;

    public GerenteDto(Gerente odj) {
       this.puesto= new SimpleStringProperty(odj.getPuesto()) ;
    }

    public String getPuesto() {
        return puesto.get();
    }

    public void setPuesto(String puesto) {
        this.puesto.set(puesto);
    }
    
    
}
