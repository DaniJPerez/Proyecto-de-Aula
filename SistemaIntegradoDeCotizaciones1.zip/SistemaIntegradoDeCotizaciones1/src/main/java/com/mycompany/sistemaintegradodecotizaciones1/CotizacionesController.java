/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.mycompany.sistemaintegradodecotizaciones1;

import com.mycompany.sistemaintegradodeCotizaciones1.entidades.DetalleCotizacion;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author f
 */
public class CotizacionesController implements Initializable {
    
    private Button botonAgregarProducto,botonCancelar,botonEliminarProducto,botonCotizar,botonRegistrarUsuario;
    private ListView<DetalleCotizacion> listaProductos;
    private TextField texNIdentidad,texNombre,texTelefono,texDireccion;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
