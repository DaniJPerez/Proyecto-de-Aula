/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.sistemaintegradodeCotizaciones1.persistencia;

import com.mycompany.sistemaintegradodeCotizaciones1.entidades.Producto;
import java.util.List;

/**
 *
 * @author f
 */
public interface ImpInventario {
    public boolean agregarProducto(Producto a);
    public boolean eliminarProducto(Producto a);
    public Producto buscarProducto(int a);
    public Producto obtenerProducto(Producto a);
    public List<Producto> getListaProductos();
}
